<?php 
$setting = ["mail_to" => "c.ontac.hamza@gmail.com","debug_mode" => false];
?>